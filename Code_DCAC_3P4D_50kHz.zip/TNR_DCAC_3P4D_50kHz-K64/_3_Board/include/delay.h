/*
 * delay.h
 *
 *  Created on: 26 Nov 2018
 *      Author: Dinh Ngoc
 */

#ifndef _INCLUDE_DELAY_H_
#define _INCLUDE_DELAY_H_


void DelayUs(unsigned int);
void DelayMs(unsigned long ms);
void DelayS(unsigned long s);

#endif /* 3_BOARD_INCLUDE_DELAY_H_ */
